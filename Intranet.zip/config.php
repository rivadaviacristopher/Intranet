<?php

$config = array(
	'bd' => array(
		'host' => 'localhost',
		'user' => 'root',
		'pass' => 'root',
		'dbname' => 'bdintranet'
		)

	);
